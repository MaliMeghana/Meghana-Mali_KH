import java.util.*;

class Pattern13
{
 public static void main(String args[])
  {
	  int num;
	  Scanner sc=new Scanner(System.in);
	  System.out.println("Enter value");
	  num=sc.nextInt();
	  int m=num;
          int k=0;
	 for (int i = 1; i <= num; i++)  
        { 
            
            for (int j = i; j < num; j++)  
                System.out.print(" "); 
            while (k != (2 * i - 1)) { 
                if (k == 0 || k == 2 * i - 2) 
                    System.out.print("*"); 
                else
                    System.out.print(" "); 
                k++; 
                ; 
            } 
            k = 0; 
            System.out.println();  
        } 
        // print last row 
        for (int i = 1; i < 2 * num - 1; i++)  
            System.out.print("*"); 
	  
  }
}